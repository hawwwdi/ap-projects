package project;
/**
 * the interface use as marker for colorful card
 */
public interface Colorful {
}
